{/* <div class="" id="table_data">
  <div class="table_elem" id="elem_0">
    <div id="elem_type" class="elem_type elem">
      Дом
    </div>
    <div class="line"></div>
    <div class="elem_currency elem">USD</div>
    <div class="line"></div>
    <button class="elem_amount elem green" id="elem_amount">
      1000
    </button>
    <div class="line"></div>
    <div class="elem_description elem">asd asd asda</div>
    <div class="line"></div>
    <div class="elem_date elem">2022-09-06</div>
  </div>{" "}
  <div class="table_elem" id="elem_1">
    <div id="elem_type" class="elem_type elem">
      Дом
    </div>
    <div class="line"></div>
    <div class="elem_currency elem">UAH</div>
    <div class="line"></div>
    <button class="elem_amount elem green" id="elem_amount">
      1000
    </button>
    <div class="line"></div>
    <div class="elem_description elem">asd asd asda</div>
    <div class="line"></div>
    <div class="elem_date elem">2022-09-06</div>
  </div>{" "}
  <div class="table_elem" id="elem_2">
    <div id="elem_type" class="elem_type elem">
      Дом
    </div>
    <div class="line"></div>
    <div class="elem_currency elem">USD</div>
    <div class="line"></div>
    <button class="elem_amount elem green" id="elem_amount">
      1000
    </button>
    <div class="line"></div>
    <div class="elem_description elem">asd asd asda</div>
    <div class="line"></div>
    <div class="elem_date elem">2022-09-06</div>
  </div>{" "}
  <div class="table_elem" id="elem_3">
    <div id="elem_type" class="elem_type elem">
      Дом
    </div>
    <div class="line"></div>
    <div class="elem_currency elem">USD</div>
    <div class="line"></div>
    <button class="elem_amount elem red" id="elem_amount">
      -1000
    </button>
    <div class="line"></div>
    <div class="elem_description elem">asd asd asda</div>
    <div class="line"></div>
    <div class="elem_date elem">2022-09-06</div>
  </div>{" "}
  <div class="table_elem" id="elem_4">
    <div id="elem_type" class="elem_type elem">
      Работа
    </div>
    <div class="line"></div>
    <div class="elem_currency elem">EUR</div>
    <div class="line"></div>
    <button class="elem_amount elem green" id="elem_amount">
      2000
    </button>
    <div class="line"></div>
    <div class="elem_description elem">asdasd asdasd</div>
    <div class="line"></div>
    <div class="elem_date elem">2022-08-06</div>
  </div>
</div> */}
